package com.example.monopoly.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.monopoly.com.example.monopolya.MonopolyViewModel
import com.example.monopoly.com.example.monopolya.GameStatus
import com.example.monopoly.com.example.monopolya.Player

@Composable
fun MonopolyGameScreen(viewModel: MonopolyViewModel = viewModel()) {
    val state by viewModel.gameState

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Заголовок
        Text(
            text = "Упрощённая Monopoly",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Информация о текущем игроке
        if (state.gameStatus != GameStatus.GAME_OVER) {
            val currentPlayer = state.players[state.currentPlayerIndex]
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(android.graphics.Color.parseColor(currentPlayer.color))),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("Ход: ${currentPlayer.name}", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    Text("Деньги: $${currentPlayer.money}")
                    Text("Позиция: ${state.properties[currentPlayer.position].name}")
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Кнопки управления
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Button(onClick = { viewModel.rollDice() }) {
                Text("🎲 Бросить кубик")
            }
            Button(onClick = { viewModel.buyCurrentProperty() }) {
                Text("💰 Купить")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Список игроков
        Text("Игроки:", fontWeight = FontWeight.Bold)
        LazyColumn {
            items(state.players.size) { index ->
                val player = state.players[index]
                PlayerRow(player, index == state.currentPlayerIndex && state.gameStatus != GameStatus.GAME_OVER)
            }
        }

        // Game Over экран
        if (state.gameStatus == GameStatus.GAME_OVER) {
            AlertDialog(
                onDismissRequest = {},
                title = { Text("Игра окончена!") },
                text = {
                    val winner = state.players.find { it.id == state.winnerId }
                    Text("Победитель: ${winner?.name ?: "Ничья"}!")
                },
                confirmButton = {
                    Button(onClick = { viewModel.restartGame() }) {
                        Text("Новая игра")
                    }
                }
            )
        }
    }
}

@Composable
fun PlayerRow(player: Player, isActive: Boolean) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(4.dp)
            .background(
                if (isActive) Color.LightGray.copy(alpha = 0.3f)
                else Color.Transparent
            )
            .clip(RoundedCornerShape(8.dp))
            .padding(8.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row {
            Box(
                modifier = Modifier
                    .size(16.dp)
                    .background(Color(android.graphics.Color.parseColor(player.color)))
                    .clip(RoundedCornerShape(4.dp))
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text("${player.name}")
        }
        Text("$${player.money}")
        Text("Собственность: ${player.properties.size}")
    }
}