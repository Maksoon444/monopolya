package com.example.monopoly.com.example.monopolya

import android.os.Parcel
import android.os.Parcelable

data class Player(
    val id: String,
    val name: String,
    var position: Int = 0,
    var money: Int = 1500,
    val properties: MutableList<Int> = mutableListOf(),
    var isInJail: Boolean = false,
    var jailTurnsLeft: Int = 0,
    var isBankrupt: Boolean = false
) : Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readInt(),
        parcel.readInt(),
        mutableListOf<Int>().apply {
            parcel.readList(this, Int::class.java.classLoader)
        },
        parcel.readByte() != 0.toByte(),
        parcel.readInt(),
        parcel.readByte() != 0.toByte()
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(id)
        parcel.writeString(name)
        parcel.writeInt(position)
        parcel.writeInt(money)
        parcel.writeList(properties)
        parcel.writeByte(if (isInJail) 1 else 0)
        parcel.writeInt(jailTurnsLeft)
        parcel.writeByte(if (isBankrupt) 1 else 0)
    }

    override fun describeContents(): Int = 0

    companion object CREATOR : Parcelable.Creator<Player> {
        override fun createFromParcel(parcel: Parcel): Player {
            return Player(parcel)
        }

        override fun newArray(size: Int): Array<Player?> {
            return arrayOfNulls(size)
        }
    }
}

data class Property(
    val id: String,
    val name: String,
    val price: Int,
    val rent: Int,
    val color: String
) : Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readInt(),
        parcel.readInt(),
        parcel.readString() ?: ""
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(id)
        parcel.writeString(name)
        parcel.writeInt(price)
        parcel.writeInt(rent)
        parcel.writeString(color)
    }

    override fun describeContents(): Int = 0

    companion object CREATOR : Parcelable.Creator<Property> {
        override fun createFromParcel(parcel: Parcel): Property {
            return Property(parcel)
        }

        override fun newArray(size: Int): Array<Property?> {
            return arrayOfNulls(size)
        }
    }
}

data class Tile(
    val id: Int,
    val name: String,
    val type: TileType,
    val price: Int? = null,
    val rent: Int? = null,
    val propertyId: String? = null
) : Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readInt(),
        parcel.readString() ?: "",
        TileType.valueOf(parcel.readString() ?: "PROPERTY"),
        parcel.readValue(Int::class.java.classLoader) as? Int,
        parcel.readValue(Int::class.java.classLoader) as? Int,
        parcel.readString()
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeInt(id)
        parcel.writeString(name)
        parcel.writeString(type.name)
        parcel.writeValue(price)
        parcel.writeValue(rent)
        parcel.writeString(propertyId)
    }

    override fun describeContents(): Int = 0

    companion object CREATOR : Parcelable.Creator<Tile> {
        override fun createFromParcel(parcel: Parcel): Tile {
            return Tile(parcel)
        }

        override fun newArray(size: Int): Array<Tile?> {
            return arrayOfNulls(size)
        }
    }
}

enum class TileType {
    START,
    PROPERTY,
    COMMUNITY_CHEST,
    CHANCE,
    TAX,
    JAIL,
    GO_TO_JAIL,
    FREE_PARKING,
    RAILROAD,
    UTILITY
}

enum class GameState {
    WAITING,
    ROLLING,
    MOVING,
    BUYING,
    TRADING,
    JAIL_TURN,
    GAME_OVER
}

enum class TurnPhase {
    START_TURN,
    ROLL_DICE,
    MOVE_PLAYER,
    BUY_PROPERTY,
    PAY_RENT,
    END_TURN
}

data class GameData(
    val players: MutableList<Player> = mutableListOf(),
    var currentPlayerIndex: Int = 0,
    var gameState: GameState = GameState.WAITING,
    var diceValue: Int = 0,
    val tiles: List<Tile> = createDefaultTiles(),
    var winnerId: String? = null
)

data class Transaction(
    val fromPlayerId: String,
    val toPlayerId: String,
    val amount: Int,
    val reason: String
)

sealed class GameAction {
    data class RollDice(val playerId: String) : GameAction()
    data class BuyProperty(val playerId: String, val propertyId: String) : GameAction()
    data class EndTurn(val playerId: String) : GameAction()
    data class PayRent(val playerId: String, val propertyId: String) : GameAction()
    data class DeclareBankrupt(val playerId: String) : GameAction()
    data class BuyHouse(val playerId: String, val propertyId: String) : GameAction()
}

fun createDefaultTiles(): List<Tile> {
    return listOf(
        Tile(0, "Старт", TileType.START),
        Tile(1, "Улица 1", TileType.PROPERTY, 200, 50, "prop1"),
        Tile(2, "Общественная казна", TileType.COMMUNITY_CHEST),
        Tile(3, "Улица 2", TileType.PROPERTY, 220, 60, "prop2"),
        Tile(4, "Железная дорога", TileType.RAILROAD, 400, 100, "rail1"),
        Tile(5, "Улица 3", TileType.PROPERTY, 240, 70, "prop3"),
        Tile(6, "Шанс", TileType.CHANCE),
        Tile(7, "Улица 4", TileType.PROPERTY, 260, 80, "prop4"),
        Tile(8, "Коммунальная услуга", TileType.UTILITY, 300, 75, "util1"),
        Tile(9, "Тюрьма", TileType.JAIL),
        Tile(10, "Улица 5", TileType.PROPERTY, 280, 90, "prop5"),
        Tile(11, "Железная дорога", TileType.RAILROAD, 400, 100, "rail2"),
        Tile(12, "Шанс", TileType.CHANCE),
        Tile(13, "Улица 6", TileType.PROPERTY, 300, 100, "prop6"),
        Tile(14, "Улица 7", TileType.PROPERTY, 320, 110, "prop7"),
        Tile(15, "Общественная казна", TileType.COMMUNITY_CHEST),
        Tile(16, "Улица 8", TileType.PROPERTY, 340, 120, "prop8"),
        Tile(17, "Шанс", TileType.CHANCE),
        Tile(18, "Железная дорога", TileType.RAILROAD, 400, 100, "rail3"),
        Tile(19, "Улица 9", TileType.PROPERTY, 360, 130, "prop9"),
        Tile(20, "Бесплатная парковка", TileType.FREE_PARKING),
        Tile(21, "Улица 10", TileType.PROPERTY, 380, 140, "prop10"),
        Tile(22, "Шанс", TileType.CHANCE),
        Tile(23, "Улица 11", TileType.PROPERTY, 400, 150, "prop11"),
        Tile(24, "Железная дорога", TileType.RAILROAD, 400, 100, "rail4"),
        Tile(25, "Улица 12", TileType.PROPERTY, 420, 160, "prop12"),
        Tile(26, "Общественная казна", TileType.COMMUNITY_CHEST),
        Tile(27, "Улица 13", TileType.PROPERTY, 440, 170, "prop13"),
        Tile(28, "Коммунальная услуга", TileType.UTILITY, 300, 75, "util2"),
        Tile(29, "Улица 14", TileType.PROPERTY, 460, 180, "prop14"),
        Tile(30, "Шанс", TileType.CHANCE),
        Tile(31, "Улица 15", TileType.PROPERTY, 480, 190, "prop15"),
        Tile(32, "Идите в тюрьму", TileType.GO_TO_JAIL),
        Tile(33, "Улица 16", TileType.PROPERTY, 500, 200, "prop16"),
        Tile(34, "Общественная казна", TileType.COMMUNITY_CHEST),
        Tile(35, "Улица 17", TileType.PROPERTY, 520, 210, "prop17"),
        Tile(36, "Шанс", TileType.CHANCE),
        Tile(37, "Улица 18", TileType.PROPERTY, 540, 220, "prop18"),
        Tile(38, "Налог", TileType.TAX, 200),
        Tile(39, "Улица 19", TileType.PROPERTY, 560, 230, "prop19"),
        Tile(40, "Улица 20", TileType.PROPERTY, 580, 240, "prop20")
    )
}