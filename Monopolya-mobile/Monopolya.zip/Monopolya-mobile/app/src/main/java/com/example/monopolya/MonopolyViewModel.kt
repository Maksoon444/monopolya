package com.example.monopoly.com.example.monopolya

import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import kotlin.random.Random

class MonopolyViewModel : ViewModel() {
    var gameState by mutableStateOf(createInitialGameState())
        private set

    private fun createInitialGameState(): GameState {
        val players = listOf(
            Player(0, "Красный", 1500, 0, false, 0, mutableListOf(), "#FF5722"),
            Player(1, "Синий", 1500, 0, false, 0, mutableListOf(), "#2196F3"),
            Player(2, "Зелёный", 1500, 0, false, 0, mutableListOf(), "#4CAF50")
        )
        val properties = listOf(
            Property(0, "Старт", 0, 0, null, "special"),
            Property(1, "Улица Ленина", 200, 50, null, "brown"),
            Property(2, "Шанс", 0, 0, null, "chance"),
            Property(3, "Улица Пушкина", 240, 60, null, "brown"),
            Property(4, "Налог", 0, 100, null, "tax"),
            Property(5, "Парк Горького", 280, 70, null, "lightblue"),
            Property(6, "Тюрьма", 0, 0, null, "jail"),
            Property(7, "Улица Гагарина", 320, 80, null, "lightblue"),
            Property(8, "Отдых", 0, 0, null, "rest"),
            Property(9, "Улица Мира", 360, 90, null, "orange")
        )
        return GameState(players, 0, properties)
    }

    fun rollDice() {
        val currentState = gameState
        if (currentState.gameStatus == GameStatus.GAME_OVER) return

        val dice = Random.nextInt(1, 7)
        val player = currentState.players[currentState.currentPlayerIndex]

        if (player.isInJail) {
            handleJailTurn(player, dice)
            return
        }

        movePlayer(player, dice)
    }

    private fun movePlayer(player: Player, dice: Int) {
        var newPosition = (player.position + dice) % gameState.properties.size
        var passedStart = player.position + dice >= gameState.properties.size
        val property = gameState.properties[newPosition]

        // Проход через Старт
        if (passedStart) {
            player.money += 200
        }

        // Обработка клетки
        when {
            property.name == "Тюрьма" -> {
                player.isInJail = true
                player.jailTurns = 0
                player.position = newPosition
            }
            property.name == "Шанс" -> applyChance(player)
            property.name == "Налог" -> {
                player.money -= property.rent
                if (player.money < 0) player.money = 0
            }
            property.name == "Отдых" -> {
                // ничего не происходит
            }
            property.ownerId == null && property.price > 0 -> {
                // Можно купить (будет отдельный метод)
            }
            property.ownerId != null && property.ownerId != player.id -> {
                val owner = gameState.players.find { it.id == property.ownerId }
                owner?.let {
                    val rentToPay = property.rent * (1 + property.houses)
                    player.money -= rentToPay
                    it.money += rentToPay
                    if (player.money < 0) player.money = 0
                }
            }
        }

        player.position = newPosition

        // Проверка банкротства
        if (player.money <= 0) {
            endGame(player)
            return
        }

        nextTurn()
    }

    private fun handleJailTurn(player: Player, dice: Int) {
        if (dice == 6) {
            player.isInJail = false
            player.jailTurns = 0
            movePlayer(player, dice)
        } else {
            player.jailTurns++
            if (player.jailTurns >= 3) {
                player.money -= 50
                player.isInJail = false
                player.jailTurns = 0
                movePlayer(player, dice)
            } else {
                nextTurn()
            }
        }
    }

    private fun applyChance(player: Player) {
        val chance = Random.nextInt(1, 5)
        when (chance) {
            1 -> player.money += 100
            2 -> player.money -= 50
            3 -> player.position = 0 // на старт
            4 -> player.isInJail = true
        }
        if (player.money < 0) player.money = 0
    }

    fun buyCurrentProperty() {
        val state = gameState
        val player = state.players[state.currentPlayerIndex]
        val property = state.properties[player.position]

        if (property.ownerId == null && property.price > 0 && player.money >= property.price) {
            player.money -= property.price
            property.ownerId = player.id
            player.properties.add(property)
            nextTurn()
        }
    }

    private fun nextTurn() {
        val newIndex = (gameState.currentPlayerIndex + 1) % gameState.players.size
        gameState = gameState.copy(
            currentPlayerIndex = newIndex,
            diceValue = 0
        )
    }

    private fun endGame(loser: Player) {
        val remainingPlayers = gameState.players.filter { it.money > 0 && it.id != loser.id }
        val winner = remainingPlayers.maxByOrNull { it.money }
        gameState = gameState.copy(
            gameStatus = GameStatus.GAME_OVER,
            winnerId = winner?.id
        )
    }

    fun restartGame() {
        gameState = createInitialGameState()
    }
}