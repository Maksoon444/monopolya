plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    // Удалите или закомментируйте id("kotlin-parcelize")
}

android {
    namespace = "com.example.monopoly"
    var compileSdk = 36

    defaultConfig {
        applicationId = "com.example.monopoly"
        minSdk = 24
        var targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }

    kotlinOptions {
        jvmTarget = "1.8"
    }

    buildFeatures {
        compose = true
        viewBinding = true
    }

    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.4"
    }
    buildToolsVersion = "36.0.0"
}

dependencies {
    implementation(libs.androidx.core.ktx.v1180)
    implementation(libs.androidx.lifecycle.runtime.ktx.v2100)
    implementation(libs.androidx.activity.compose.v1130)
    implementation(libs.androidx.compose.ui.v154)
    implementation(libs.androidx.compose.ui.ui.tooling.preview)
    implementation(libs.androidx.compose.material3.v112)

    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit.v115)
    androidTestImplementation(libs.androidx.espresso.core.v351)
}